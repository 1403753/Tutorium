int square(int number){
	return number*number;
}

int cube(int number){
	int squaredNumber=square(number);
	return squaredNumber*number;
}

int main(){
	int number=3;
	number=cube(number);
	return 0;
}
