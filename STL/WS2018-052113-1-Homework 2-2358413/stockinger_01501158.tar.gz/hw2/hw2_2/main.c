#include<stdio.h>
#include<stdlib.h>

int main(){
	const int arraySize=10;
	
	int *numbers=(int*) malloc(arraySize*sizeof(int));
	if(numbers==NULL){
		fprintf(stderr,"malloc failed\n");
		return(-1);
	}

	for(int i=0;i<arraySize;i++){
		numbers[i]=i;
	}
	
	free(numbers);
	printf("%i\n",numbers[5]);
	


	int *otherNumbers=(int*) malloc(arraySize*sizeof(int));
	if(otherNumbers==NULL){
		fprintf(stderr,"malloc failed\n");
		return(-1);
	}
	
	
	return 0;
}
	
