#include<stdio.h> 
#include<stdlib.h> 

int main(int argc, char *argv[]) {

    long n = 10; 
    float * arr1 = malloc(n * sizeof(int));
    float * arr2 = calloc(10, sizeof(int));

    printf("Only one of these values has been initialized: \n");
    printf("%f \n", arr1[0]);
    printf("%f \n", arr2[0]);
}

