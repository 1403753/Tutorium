#include<stdlib.h>  
#include<stdio.h> 
#include "vec_mul.h" 

int main() {
    long n = 10; 
    double a = 1.5;
    double * vec = malloc(n * sizeof(double));

    for(long i = 0; i < n; i++) {
        vec[i] = i;
    }

    printf("vector before multiplication:\n");
    printvec(vec, n); 
    vec_mul(vec, n, a);
    printf("vector after multiplication with %f:\n", a);
    printvec(vec, n); 

    free(vec);
}





