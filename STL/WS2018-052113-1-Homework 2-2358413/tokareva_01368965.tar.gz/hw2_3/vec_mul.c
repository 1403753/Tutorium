#include<stdio.h> 
#include "vec_mul.h" 

//multiplies each element of length n vector vec with the value a
void vec_mul(double * vec, long n, double a) { 
    for(long i = 0; i < n; i++) {
        vec[i] *= a;
    }
}

// prints a length n vector of doubles
void printvec(double * vec, long n) {
    for(long i = 0; i < n; i++) {
        printf("%f ", vec[i]);
    }
    printf("\n");
}
