void vec_mul(double * vec, long n, double a);
void printvec(double * vec, long n);
