//STL WS 2018/19
//Homework 2 example 2: valgrind demo

#include <stdlib.h>

int main(){
	double *p = (double*) malloc(10 * sizeof(double)); //allocated memory is never freed: memory leak
	p[15] = 22.5; //accessing array out of bounds

	return 0;
}
