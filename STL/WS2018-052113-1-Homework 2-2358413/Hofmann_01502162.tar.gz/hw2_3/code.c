#include<stdio.h>

void vec_mul(double* vec, int size, double factor) {
	for (int i = 0; i < size; ++i) {
		vec[i] *= factor;
	}
}

int main() {
	double vector[5] = {1.,2.,3.,4.,5.};
	int size = 5;
	double factor = 3;
	
	vec_mul(vector, size, factor);
	
	for (int i = 0; i < size; ++i) {
		printf("%f ", vector[i]);
	}
	printf("\n");
}
