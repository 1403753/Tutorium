/*demonstrating Valgrind memory check valgrind picks up all memory errors - memory leak in array and access outside array
 * Invalid write of size ... tells us that the program wrote in memory it should'nt have, ....bytesare definitely lost = program is leaking memory--must fix*/

#include<stdio.h>
#include<stdlib.h>

void f_array(){

	int *x = malloc(19);
	x[10] = 0; // unused space in array
	int z = x[20]; // variable allocated with nonexisting value
	printf("Var z: %d",z);

}	


int main(){

	f_array();


	return 0;
}
