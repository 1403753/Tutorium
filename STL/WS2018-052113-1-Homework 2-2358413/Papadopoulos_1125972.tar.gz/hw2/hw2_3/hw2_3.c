/* gdb commands: break 5,break 17,run,s-for stepwise continuing,print result - for printing variable,c -for continue to next break point,print number, print entered,c,quit*/

#include <stdio.h>
 
long factorial(int n){
  
  long result = 1;
 
  for (int i = 1; i <= n; i++){
    result = result * i;
  }
  return result;
}
 
int main()
{
  int number = 12;
  long entered = factorial(number); 
  printf("%d! = %ld\n", number, entered);
 
  return 0;
}
