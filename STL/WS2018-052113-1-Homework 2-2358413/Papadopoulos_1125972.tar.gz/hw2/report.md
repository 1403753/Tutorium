---
title: STL Homework 1 Report
date: 2018-10-14
author: Apostolos Papadopoulos, 1125972; Martin Sipiczki, 01367652
---

Exercises available at `harris` directories:

* `/home/a01125972/exercises/hw1/`
* `/home/a01367652/exercises/hw1/`

# Exercise 1

The generated figure is listed below.

![Gnuplot](hw2_1/hw2_1.png)

# Exercise 2

``` {.bash}
$ make
gcc -Wall -std=iso9899:2011 -pedantic -g -c hw2_2.c
gcc -o hw2_2 hw2_2.o
valgrind --tool=memcheck --leak-check=yes ./hw2_2
==56553== Memcheck, a memory error detector
==56553== Copyright (C) 2002-2017, and GNU GPL'd, by Julian Seward et al.
==56553== Using Valgrind-3.13.0 and LibVEX; rerun with -h for copyright info
==56553== Command: ./hw2_2
==56553==
==56553== Invalid write of size 4
==56553==    at 0x1086A8: f_array (hw2_2.c:10)
==56553==    by 0x1086DE: main (hw2_2.c:19)
==56553==  Address 0x521c068 is 21 bytes after a block of size 19 alloc'd
==56553==    at 0x4C2FB0F: malloc (in /usr/lib/valgrind/vgpreload_memcheck-amd64-linux.so)
==56553==    by 0x10869B: f_array (hw2_2.c:9)
==56553==    by 0x1086DE: main (hw2_2.c:19)
==56553==
==56553== Invalid read of size 4
==56553==    at 0x1086B2: f_array (hw2_2.c:11)
==56553==    by 0x1086DE: main (hw2_2.c:19)
==56553==  Address 0x521c090 is 16 bytes before an unallocated block of size 4,194,112 in arena "client"
==56553==
Var z: 0==56553==
==56553== HEAP SUMMARY:
==56553==     in use at exit: 19 bytes in 1 blocks
==56553==   total heap usage: 2 allocs, 1 frees, 1,043 bytes allocated
==56553==
==56553== 19 bytes in 1 blocks are definitely lost in loss record 1 of 1
==56553==    at 0x4C2FB0F: malloc (in /usr/lib/valgrind/vgpreload_memcheck-amd64-linux.so)
==56553==    by 0x10869B: f_array (hw2_2.c:9)
==56553==    by 0x1086DE: main (hw2_2.c:19)
==56553==
==56553== LEAK SUMMARY:
==56553==    definitely lost: 19 bytes in 1 blocks
==56553==    indirectly lost: 0 bytes in 0 blocks
==56553==      possibly lost: 0 bytes in 0 blocks
==56553==    still reachable: 0 bytes in 0 blocks
==56553==         suppressed: 0 bytes in 0 blocks
==56553==
==56553== For counts of detected and suppressed errors, rerun with: -v
==56553== ERROR SUMMARY: 3 errors from 3 contexts (suppressed: 0 from 0)
```

# Exercise 3

``` {.bash}
$ make
gcc -Wall -std=iso9899:2011 -pedantic -ggdb -c hw2_3.c
gcc -o hw2_3 hw2_3.o
gdb hw2_3
GNU gdb (Ubuntu 8.0.1-0ubuntu1) 8.0.1
Copyright (C) 2017 Free Software Foundation, Inc.
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.  Type "show copying"
and "show warranty" for details.
This GDB was configured as "x86_64-linux-gnu".
Type "show configuration" for configuration details.
For bug reporting instructions, please see:
<http://www.gnu.org/software/gdb/bugs/>.
Find the GDB manual and other documentation resources online at:
<http://www.gnu.org/software/gdb/documentation/>.
For help, type "help".
Type "apropos word" to search for commands related to "word"...
Reading symbols from hw2_3...done.
(gdb) break 5
Breakpoint 1 at 0x651: file hw2_3.c, line 5.
(gdb) break 17
Breakpoint 2 at 0x68d: file hw2_3.c, line 17.
(gdb) run main
Starting program: /home/a01125972/exercises/hw2/hw2_3/hw2_3 main

Breakpoint 2, main () at hw2_3.c:17
17	  int number = 12;
(gdb) s
18	  long entered = factorial(number);
(gdb) p number
$2 = 12
(gdb) continue
Continuing.

Breakpoint 1, factorial (n=12) at hw2_3.c:7
7	  long result = 1;
(gdb) s
9	  for (int i = 1; i <= n; i++){
(gdb) s
10	    result = result * i;
(gdb) s
9	  for (int i = 1; i <= n; i++){
(gdb) continue
Continuing.
12! = 479001600
[Inferior 1 (process 57594) exited normally]
```
