#include <stdio.h>

int add(int a, int b){
	return a+b;
}

int main(){
	
	int sum,a=4,b=6;
	sum=add(a,b);
	sum+=sum;
	
	return 0;
}