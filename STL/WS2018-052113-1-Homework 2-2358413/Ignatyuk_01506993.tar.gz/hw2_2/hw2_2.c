#include <stdio.h>
#include <stdlib.h>

int main(void){
	
	int* x = malloc(10 * sizeof(int));
    x[100] = 0;
	
	double a;
	printf("%f",a);
	
	return 0;
}