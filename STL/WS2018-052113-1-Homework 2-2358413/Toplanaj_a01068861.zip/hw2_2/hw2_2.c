#include <stdio.h>
#include <stdlib.h>

double determinant_2x2(double matr[][2]){
    /* Compute determinant of 2x2 matrix */
    return matr[0][0]*matr[1][1]-matr[0][1]*matr[1][0];
}

double (*matr_inv_2x2(double matr[][2]))[2]{
    /* Find an inverse of 2x2 matrix */
    double det = determinant_2x2(matr);
    printf("Determinant = %f\n", det);
    /* Check if the matrix is invertible */
    if(det==0){ // not invertible
        printf("Non-invertible matrix. Exit...\n");
        return NULL;
    } else { // invertible
        double (*invMatr)[2];
        /* Check if memory is allocated successfully */
        if(!(invMatr = malloc(2*2*sizeof(double)))){ //fail
            printf("Error allocating memory. Exit...\n");
            return NULL;
        } else { //success
            invMatr[0][0] = matr[1][1]/det;
            invMatr[0][1] = -matr[0][1]/det;
            invMatr[1][0] = -matr[1][0]/det;
            invMatr[1][1] = matr[0][0]/det;
            invMatr[2][0] = 5;
            return invMatr;
        }
    }
}

void print_matr_2x2(double matr[][2]){
    /* Print matrix */
    int i,j;
    for(i=0; i<2; i++){
        for(j=0; j<2; j++){
            printf("%f  ", matr[i][j]);
        }
        printf("\n");
	}
}

int main(){
    printf("Input matrix:\n");
    double matr[][2] = {{2.1, 3.2}, {4.1, 5.7}};
    //double matr[][2] = {{2, 0}, {5, 0}};
    print_matr_2x2(matr);
    double (*invMatr)[2] = matr_inv_2x2(matr);
    if((*invMatr)==NULL){
        return -1;
    } else {
        printf("Inverted matrix:\n");
	print_matr_2x2(invMatr);
        return 0;
    }
}
